﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using Model;

namespace Controller
{
    public enum ResultEnum
    {
        Failed,
        Successful
    }

    public class EmployeeController
    {
        //fields
        private EmployeeDao dao;

        //constructor
        public EmployeeController()
        {
            dao = new EmployeeDao();
        }

        //methods

        //add data
        public ResultEnum AddData(Employee emp)
        {
            try
            {
                dao.insertData(emp);
                return ResultEnum.Successful;
            }
            catch(Exception ex)
            {
                //log to console output window
                Console.WriteLine("error in EmployeeController/Add " + ex.Message);
                //report
                return ResultEnum.Failed;
            }
        }
        public ResultEnum Update(Employee emp)
        {
            try
            {
                dao.UpdateData(emp);
                return ResultEnum.Successful;
            }

            catch (Exception ex)
            {
                //log to console output window
                Console.WriteLine("error in EmployeeController/Update " + ex.Message);
                //report
                return ResultEnum.Failed;
            }
        }

        //displays all employee data
        public Result<Object> DisplayAll()
        {
            Result<Object> theResults = new Result<Object>();

            try
            {
                //call method
                theResults.Data = dao.SellectAll();
                theResults.Status = ResultEnum.Successful;
            }
            catch (Exception ex)
            {
                //logging an error
                Console.WriteLine("Error in Controller/SelectAll " + ex.Message);
                //report status
                theResults.Status = ResultEnum.Failed;
            }
            return theResults;

            //Result<Employee> theResults = Retreive(dao.SellectAll(), "DisplayAll");
            //return theResults;
        }

        public Result<Employee> SelectId(Employee emp)
        {
            Result<Employee> theResults = new Result<Employee>();

            try
            {
                //call method
                theResults.Data = dao.SelectById(emp);
                theResults.Status = ResultEnum.Successful;
            }
            catch (Exception ex)
            {
                //logging an error
                Console.WriteLine("Error in Controller/SelectId " + ex.Message);
                //report status
                theResults.Status = ResultEnum.Failed;
            }
            return theResults;

            //Result<Employee> theResults = Retreive(dao.SelectById(emp), "selectId");
            //return theResults;

        }

        public Result<Employee> SelectEmail(Employee emp)
        {
            Result<Employee> theResults = new Result<Employee>();

            try
            {
                //call method
                theResults.Data = dao.SelectByEmail(emp);
                theResults.Status = ResultEnum.Successful;
            }
            catch (Exception ex)
            {
                //logging an error
                Console.WriteLine("Error in Controller/SellectEmail " + ex.Message);
                //report status
                theResults.Status = ResultEnum.Failed;
            }
            return theResults;
        }

        //reader controller
        //public Result<Employee> Retreive(List<Employee> dataSource, string error)
        //{
        //    Result<Employee> theResults = new Result<Employee>();

        //    try
        //    {
        //        //call method
        //        theResults.Data = dataSource;
        //        theResults.Status = ResultEnum.Successful;
        //    }
        //    catch (Exception ex)
        //    {
        //        //logging an error
        //        Console.WriteLine("Error in Controller/" + error + " " + ex.Message);
        //        //report status
        //        theResults.Status = ResultEnum.Failed;
        //    }
        //    return theResults;
        //}

    }
}
