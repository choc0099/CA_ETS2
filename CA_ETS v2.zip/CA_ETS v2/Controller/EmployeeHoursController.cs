﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using DataAccess;

namespace Controller
{
    public class EmployeeHoursController
    {
        private EmployeeHoursDao dao;

        public EmployeeHoursController()
        {
            dao = new EmployeeHoursDao();
        }

        //insert data to EmpHours table
        public ResultEnum AddData(EmployeeHours eh)
        {
            
            try
            {
                //call method
                dao.InsertData(eh);
                //report
                return ResultEnum.Successful;
            }

            catch(Exception ex)
            {
                //logging an error to console
                Console.WriteLine("Error in EmployeeHoursController/AddData " + ex.Message);
                //report
                return ResultEnum.Failed;
            }
        }

        public Result<Object> DisplayHours()
        {
            Result<Object> theResults = new Result<Object>();

            try
            {
                theResults.Data = dao.GetHours();
                theResults.Status = ResultEnum.Successful;
            }
            catch(Exception ex)
            {
                //log to console
                Console.WriteLine("Error in EmployeeHoursController/DisplayHours " + ex.Message);
                //report
                theResults.Status = ResultEnum.Failed;
            }
            return theResults;
        }
    }
}
