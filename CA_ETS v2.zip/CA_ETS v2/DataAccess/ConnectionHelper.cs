﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;

namespace DataAccess
{
    public static class ConnectionHelper
    {
        public static void EmployeeData(string sp, Employee emp)
        {

            //1 connection to sql server
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionHelper.getConnectionStr();
            con.Open();

            using (con)
            {
                //2 - set command
                SqlCommand command = new SqlCommand(sp, con);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //stored procedures parameters
                command.Parameters.Add(new SqlParameter("@firstName", emp.FirstName));
                command.Parameters.Add(new SqlParameter("@lastName", emp.LastName));
                command.Parameters.Add(new SqlParameter("@email", emp.EmailAddress));
                command.Parameters.Add(new SqlParameter("@dob", emp.DOB.ToString("yyyy-MM-dd")));
                command.Parameters.Add(new SqlParameter("@phone", emp.PhoneNumber));

                //3 - run command
                command.ExecuteNonQuery();
            }
        }

        public static List<Employee> RetrieveData(string sp, string parameter, object input)
        {
           // emp = new Employee();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionHelper.getConnectionStr();
            con.Open();

            using (con)
            {
                SqlCommand command = new SqlCommand(sp, con);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //Parameters
                command.Parameters.Add(new SqlParameter(parameter, input));

                SqlDataReader reader = command.ExecuteReader();

                //map reader
                List<Employee> list = new List<Employee>();
                //read method
                while (reader.Read())
                {
                    Employee emp = new Employee();
                    emp.EmployeeId = Convert.ToInt32(reader["EmployeeID"]);
                    emp.FirstName = Convert.ToString(reader["FirstName"]);
                    emp.LastName = Convert.ToString(reader["LastName"]);
                    emp.DOB = Convert.ToDateTime(reader["DOB"]);
                    emp.EmailAddress = Convert.ToString(reader["EmailAddress"]);
                    emp.PhoneNumber = Convert.ToString(reader["PhoneNumber"]);
                    list.Add(emp);
                }//end loop
                return list;
            }

        }

        public static List<Object> RetrieveData(string sp)
        {
            bool employeeTbl = sp.Contains("Employees");
            bool empHoursTbl = sp.Contains("EmpHours");
            // emp = new Employee();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionHelper.getConnectionStr();
            con.Open();

            using (con)
            {
                SqlCommand command = new SqlCommand(sp, con);
                command.CommandType = System.Data.CommandType.StoredProcedure;
               
                SqlDataReader reader = command.ExecuteReader();

                //map reader
                List<Object> list = new List<Object>();
                //read method
                while (reader.Read())
                {
                    if (employeeTbl)
                    {
                        Employee emp = new Employee();
                        emp.EmployeeId = Convert.ToInt32(reader["EmployeeID"]);
                        emp.FirstName = Convert.ToString(reader["FirstName"]);
                        emp.LastName = Convert.ToString(reader["LastName"]);
                        emp.DOB = Convert.ToDateTime(reader["DOB"]);
                        emp.EmailAddress = Convert.ToString(reader["EmailAddress"]);
                        emp.PhoneNumber = Convert.ToString(reader["PhoneNumber"]);
                        list.Add(emp);
                    }
                    else if (empHoursTbl)
                    {
                        EmployeeHours eh = new EmployeeHours();
                        eh.Hours = Convert.ToInt32(reader["Hours"]);
                    }
                   
                }//end loop
                return list;
            }

        }




        //connection string method
        public static string getConnectionStr()
        {
            return "Data Source=.;Initial Catalog=CA_ETCDataBase;Integrated Security=True";
        }
    }
}
