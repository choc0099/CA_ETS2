﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;


namespace DataAccess
{
    public static class DataReaderHelper
    {
        //reader method
        //sql data reader method
        public static List<Employee> ReadData(string sp, SqlConnection con)
        {

            SqlCommand command;
            command = new SqlCommand(sp, con);
            SqlDataReader reader = command.ExecuteReader();

            //map reader
            List<Employee> list = new List<Employee>();
            //read method
            while (reader.Read())
            {
                Employee emp = new Employee();
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeID"]);
                emp.FirstName = Convert.ToString(reader["FirstName"]);
                emp.LastName = Convert.ToString(reader["LastName"]);
                emp.DOB = Convert.ToDateTime(reader["DOB"]);
                emp.EmailAddress = Convert.ToString(reader["EmailAddress"]);
                emp.PhoneNumber = Convert.ToString(reader["PhoneNumber"]);
                list.Add(emp);
                //reader.Close();
            }//end loop
            return list;
        }
    }
}
