﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;

namespace DataAccess
{
    public class EmployeeDao
    {
        Employee emp = new Employee();

        //insert data into the database method
        public void insertData(Employee emp)
        {
            ConnectionHelper.EmployeeData("sp_Employees_Insert", emp);
        }
            
        //Update Employee information
        public void UpdateData(Employee emp)
        {
            ConnectionHelper.EmployeeData("sp_Employees_Update", emp);
        }


        //select all data methodf
        public List<Object> SellectAll()
        { 
            List<Object> list = ConnectionHelper.RetrieveData("sp_Employees_SelectAll");
            return list;
        }

        public List<Employee> SelectById(Employee emp)
        {
            //Employee ep = new Employee();
            List<Employee> list = ConnectionHelper.RetrieveData("sp_Employees_SelectById", "@employeeId", emp.EmployeeId);
            return list;
        }

        //Retrieve data by email address
        public List<Employee> SelectByEmail(Employee emp)
        {
            //emp = new Employee();
            List<Employee> list = ConnectionHelper.RetrieveData("sp_Employees_SelectByEmail", "@email", emp.EmailAddress);
            return list;
        }       
    }
}
