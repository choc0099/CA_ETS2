﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;

namespace DataAccess
{
    public class EmployeeHoursDao
    {
        //insert data to EmployeeHours table
        public void InsertData(EmployeeHours eh)
        {
            //1 - connection to sql server
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionHelper.getConnectionStr();
            con.Open();

            using (con)
            {
                //2 - get command
                SqlCommand command = new SqlCommand("sp_EmplHours_Insert", con);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //parameters
                command.Parameters.Add(new SqlParameter("@empId", eh.EmployeeId));
                command.Parameters.Add(new SqlParameter("@workDate", eh.WorkDate));
                command.Parameters.Add(new SqlParameter("@hourWorked", eh.Hours));

                //3 - run command
                command.ExecuteNonQuery();
            }
        }

        public List<Object> GetHours()
        {
            List<Object> list = ConnectionHelper.RetrieveData("sp_EmpHOurs_SelectAll");
            return list;
        }
    }
}
