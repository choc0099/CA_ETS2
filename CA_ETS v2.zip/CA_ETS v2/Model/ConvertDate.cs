﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public static class ConvertDate
    {
       private static DateTime myDate = DateTime.Now;


        public static string sqlFormat = myDate.ToString("yyyy-mm-dd");

       
    }
}
