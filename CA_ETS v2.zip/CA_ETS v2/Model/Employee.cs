﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Employee
    {
        //fields and properties
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }

        

        //method output
        public override string ToString()
        {
            return EmployeeId + ", " + FirstName + ", " + LastName + ", "+ EmailAddress +", " + DOB.ToShortDateString() + ", " + PhoneNumber + "\n"; 
        }

        
    }
}
