﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class EmployeeHours
    {
        //fields and properties
        public int EmployeeId { get; set; }
        public int EmpHourId { get; set; }
        public int Hours { get; set; }
        public DateTime WorkDate { get; set; }

        //method output
        public override string ToString()
        {
            return EmployeeId + ", " + EmpHourId + ", " + Hours + ", " + WorkDate.ToShortDateString();
        }


    }
}
