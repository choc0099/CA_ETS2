﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using Controller;
using System.Globalization;

namespace View
{
    public partial class AddNewEmployeeForm : Form
    {
        public AddNewEmployeeForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //convert to sql date format
            CultureInfo provider = CultureInfo.InvariantCulture;

            //Read input
            Employee emp = new Employee();
            emp.FirstName = txtFirstName.Text;
            emp.LastName = txtLastName.Text;
            emp.DOB = DateTime.ParseExact(dtpDOB.Text, "dd/MM/yyyy", provider);
            emp.EmailAddress = txtEmail.Text;
            emp.PhoneNumber = txtPhone.Text;

            //try
            //{
            //    MessageBox.Show(emp.ToString());
            //}
            //catch(FormatException)
            //{
            //    MessageBox.Show("unable to convert date format.");
            //}


            //call controller
            EmployeeController controller = new EmployeeController();
            ResultEnum result = controller.AddData(emp);
            if(result == ResultEnum.Successful)
            {
                //show output
                MessageBox.Show(emp.ToString());
                MessageBox.Show("Data has been added successfully.");
            }
            else
            {
                //Error
                MessageBox.Show(emp.ToString());
                MessageBox.Show("Failed to add data.");
            }
        }
    }
}
