﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using Controller;
using System.Collections.Generic;

namespace View
{
    public partial class DisplayAllEmployeeDataForm : Form
    {
        //Employee empArr[]
        public DisplayAllEmployeeDataForm()
        {
            InitializeComponent();
        }

        private void DisplayAllEmployeeDataForm_Load(object sender, EventArgs e)
        {
            LoadData();

            lblHours.Text = TotalHours().ToString();
        }

        public void LoadData()
        {
            //call Sellect all Employees contoller
            EmployeeController controller = new EmployeeController();
            //Employee emp = new Employee();
            Result<Object> result = controller.DisplayAll();

            //show output
            if (result.Status == ResultEnum.Successful)
            {
                gdvDisplayData.DataSource = result.Data;
                //lblOutput.Text = emp.ToString();
            }
            else
            {
                MessageBox.Show("Unable to load data.");
            }
        }

        //show total hours
        public int TotalHours()
        {
            //call controller
            EmployeeHoursController controller = new EmployeeHoursController();

            Result<Object> results = controller.DisplayHours();

            int total = 0;
            if (results.Status == ResultEnum.Successful)
            {

                List<Object>  list = results.Data;

                //int number = 0;


                Object obj = new object();
                int count = 0;
                for (int i = 0; i<list.Count; i++)
                {
                    (EmployeeHours)ob
                    
                    
                    
                }
                
            }
            else
            {
                total = 0;
            }
            return total;
            
        }
    }
}
