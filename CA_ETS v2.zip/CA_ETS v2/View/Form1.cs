﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void updateDataToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void displayReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewEmployeeForm frm = new AddNewEmployeeForm();
            frm.ShowDialog();
        }

        private void allEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DisplayAllEmployeeDataForm frm = new DisplayAllEmployeeDataForm();
            frm.ShowDialog();
        }

        private void updateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateEmployeesForm frm = new UpdateEmployeesForm();
            frm.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void employeeByIDEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchEmployeeForm frm = new SearchEmployeeForm();
            frm.ShowDialog();
        }
    }
}
