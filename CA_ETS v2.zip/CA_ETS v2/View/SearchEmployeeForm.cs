﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using Controller;

namespace View
{
    public partial class SearchEmployeeForm : Form
    {
        public SearchEmployeeForm()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //read input
            string searchBy = cmbFindBy.Text;
            string search = txtSearch.Text;
        
            Employee emp = new Employee();
            EmployeeController controller = new EmployeeController();
           
            Result<Employee> resultId = controller.SelectId(emp);

            if (searchBy == "Email")
            {
                emp.EmailAddress = search;
                Result<Employee> result = controller.SelectEmail(emp);
                if (result.Status == ResultEnum.Successful)
                {
                    dgvDisplayData.DataSource = result.Data;
                }
                else
                {
                    MessageBox.Show("Cannot retreive data");
                }
            }
            else if (searchBy == "EmployeeID")
            {
                emp.EmployeeId = int.Parse(search);
                Result<Employee> result = controller.SelectId(emp);
                if (result.Status == ResultEnum.Successful)
                {
                    dgvDisplayData.DataSource = result.Data;
                }
                else
                {
                    MessageBox.Show("Cannot retreive data");
                }
            }
           
        }
    }
}
