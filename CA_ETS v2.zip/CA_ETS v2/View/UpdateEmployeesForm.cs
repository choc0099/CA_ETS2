﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller;
using Model;
using System.Globalization;

namespace View
{
    public partial class UpdateEmployeesForm : Form
    {
        public UpdateEmployeesForm()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {
          
        }

        private void lstEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            Employee selectedEmployee = (Employee)lstEmployees.SelectedItem;
            //show data
            lblEmployeeId.Text =selectedEmployee.EmployeeId.ToString();
            txtFirstName.Text = selectedEmployee.FirstName;
            txtLastName.Text = selectedEmployee.LastName;
            dtpDOB.Text = selectedEmployee.DOB.ToString("dd/MM/yyyy");
            txtEmail.Text = selectedEmployee.EmailAddress;
            txtPhone.Text = selectedEmployee.PhoneNumber;
        }

        //load method
        public void Reload()
        {
            EmployeeController controller = new EmployeeController();
            Result<Object> result = controller.DisplayAll();
            if(result.Status == ResultEnum.Successful)
            {
                lstEmployees.DataSource = result.Data;
                lstEmployees.DisplayMember = "FirstName";
                lblNumberEmployees.Text = "Number of Employes: " + result.Data.Count;
            }
            else
            {
                lstEmployees.Text = "No data avaliable";
                MessageBox.Show("Failed to load data");
            }

        }

        private void UpdateEmployeesForm_Load(object sender, EventArgs e)
        {
            //call reload method to retrieve data from the database
            Reload();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //read input for Employees
            Employee updateEmployee = new Employee();
            updateEmployee.EmployeeId = int.Parse(lblEmployeeId.Text);
            updateEmployee.FirstName = txtFirstName.Text;
            updateEmployee.LastName = txtLastName.Text;
            updateEmployee.DOB = DateTime.Parse(dtpDOB.Text);
            updateEmployee.EmailAddress = txtEmail.Text;
            updateEmployee.PhoneNumber = txtPhone.Text;

            //save to database
            EmployeeController controller = new EmployeeController();
            ResultEnum results = controller.Update(updateEmployee);
            if(results == ResultEnum.Successful)
            {
                //reload database
                Reload();
                MessageBox.Show("Your data has been updated successfully");
            }
            else
            {
                MessageBox.Show("Failed updating data");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            EmployeeHoursController controller = new EmployeeHoursController();

            //read input
            EmployeeHours eh = new EmployeeHours();
            eh.EmployeeId = int.Parse(lblEmployeeId.Text);
            eh.Hours = int.Parse(txtHours.Text);
            eh.WorkDate = DateTime.Parse(dtpWorkDate.Text);

            //call method
            ResultEnum result = controller.AddData(eh);
            if (result == ResultEnum.Successful)
            {
                MessageBox.Show("Employee hours has been added successfully");
            }
            else
            {
                MessageBox.Show("Failed to add Employee Hours", "Error!");
            }
           


        }
    }
}
